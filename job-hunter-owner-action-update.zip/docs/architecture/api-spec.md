# REST API spec

Base path `/api`. JSON only. The generated `docs/architecture/openapi.json` is the exact
contract; this file is the human-readable design. If they differ, fix the code or this file
in the same commit.

## Conventions

- Field names camelCase; timestamps ISO-8601 UTC strings; enums as upper-case strings.
- Profile: Phase 1 always uses `ProfileProvider.current()`; no profile in URLs. (Phase 4 adds
  auth and derives the profile from the user.)
- Pagination: `page` (0-based), `size` (default 25, max 100) → response
  `{ "items": [...], "page": 0, "size": 25, "totalItems": 123, "totalPages": 5 }`.
- Errors: RFC 9457 Problem Details (`application/problem+json`) via Spring's
  `ProblemDetail`: `{ "type", "title", "status", "detail", "code" }` where `code` is a stable
  machine string, e.g. `ILLEGAL_STATUS_TRANSITION`, `JOB_NOT_FOUND`, `VALIDATION_FAILED`,
  `PIPELINE_ALREADY_RUNNING`.
- No auth in Phase 1; server binds to `127.0.0.1`.
- Controllers live in the backend `api` module and call module services only.

## Jobs

### `GET /api/jobs`
Query (all optional): `status` (repeatable), `eligibility` (repeatable), `minScore`,
`maxScore`, `source` (repeatable), `employmentType` (repeatable), `postedWithinDays`, `q`
(title/company text), `includeExpired` (default false), `analysisStage` (repeatable), `sort` (`score` | `posted`, default
`score`), `page`, `size`. With no filters, the default view applies: status ∈ {NEW, SHORTLISTED}, prefilter PASS,
eligibility ≠ INELIGIBLE, ACTIVE. Scored jobs come first, by score; jobs not yet analyzed follow, by `postedAt`.

Item `JobSummary`:
```json
{ "id": 42, "title": "...", "company": "...", "locationText": "...",
  "score": 82, "scoreBand": "GOOD", "summary": "...",
  "eligibility": "ELIGIBLE", "remoteType": "REMOTE_RESTRICTED", "allowedRegions": ["EU"],
  "employmentTypes": ["CONTRACT"], "postedAt": "...", "firstSeenAt": "...",
  "sources": [{ "code": "himalayas", "name": "Himalayas" }],
  "status": "NEW", "jobStatus": "ACTIVE", "analysisStage": "NOT_ANALYZED" }
```
`scoreBand`: `EXCELLENT` ≥ 85, `GOOD` 70–84, `MAYBE` 50–69, `WEAK` < 50, `NONE` if unscored.
`analysisStage` (derived, ADR-0009): `NOT_ANALYZED` (no LLM call yet) · `ANALYZED`
(extraction and eligibility done, not scored) · `SCORED` · `FAILED` (last attempt failed; retry available).

### `GET /api/jobs/{id}`
`JobDetail` = `JobSummary` fields plus: `description`, `applyUrl`, `salary`, `tags`,
`extraction` (attributes object, scoring-spec §3), `eligibilityReasons` (string[]),
`prefilterReasons`, `scoreBreakdown`, `strengths`, `gaps`, `redFlags`, `applyAdvice`,
`postings` (`[{ sourceCode, sourceName, url, firstSeenAt, lastSeenAt }]` — the UI shows
"via <sourceName>" links), `notes`, `history` (`[{ from, to, note, at }]`),
`allowedTransitions` (statuses the UI may offer).

### `POST /api/jobs/{id}/status`
Body `{ "to": "SHORTLISTED", "note": "optional" }` → 200 with updated `JobSummary`;
409 `ILLEGAL_STATUS_TRANSITION`; 404 `JOB_NOT_FOUND`.

### `POST /api/jobs/{id}/analyze`
Owner action "Analyze" (ADR-0009). Runs extraction if no OK extraction exists for the
current prompt version (one EXTRACT call), then eligibility (no LLM). No body → 200 `JobDetail`.
Repeating it makes no LLM call. Errors: 404 `JOB_NOT_FOUND`; 409 `LLM_PAUSED` (the response
includes the `LlmAlert` for that purpose); 409 `BUDGET_REACHED`.

### `POST /api/jobs/{id}/score`
Owner action "Score" (ADR-0009). Requires an analyzed job whose eligibility is
ELIGIBLE or UNCERTAIN; makes one SCORE call → 200 `JobDetail`. Repeating it makes no call.
Errors: 404 `JOB_NOT_FOUND`; 409 `JOB_NOT_ANALYZED`; 409 `JOB_NOT_ELIGIBLE`; 409 `LLM_PAUSED`;
409 `BUDGET_REACHED`.

### `PUT /api/jobs/{id}/notes`
Body `{ "notes": "text ≤ 10 000 chars" }` → 204.

### `GET /api/meta`
Values for filter controls: `{ "sources": [{code,name}], "statuses": [...],
"employmentTypes": [...], "eligibilities": [...], "profileId": "hugh",
"summaryLanguage": "vi" }`.

## Admin

### `GET /api/admin/overview`
```json
{ "sources": [{ "code", "name", "enabled", "lastRun": { "status", "startedAt", "fetched",
  "newRaw", "newJobs", "error" } }],
  "pipelineReports": [ PipelineReport, ... up to 20 ],
  "llmUsage": { "monthToDateUsd", "monthlyBudgetUsd", "callsToday",
                "daily": [{ "date", "calls", "inputTokens", "outputTokens", "costUsd" }] },
  "failures": { "extractions": [{ jobId, title, attempts, lastError }], "scorings": [...] },
  "pipelineRunning": false,
  "pipelineProgress": { "stage": "SCORE", "text": "Collect 7/9 sources · scoring 14 / 27", "percent": 62 } | null,
  "schedule": { "nextRunAt": "...", "nextDigestAt": "...", "zone": "Europe/Rome" },
  "kpis": { "activeJobs": 1384, "newToday": 42, "prefilterRejectedToday": 31,
            "scoredToday": 9, "alertsToday": 2, "toReview": 37,
            "sourceCount": 9, "companyBoardCount": 6 },
  "llmAlerts": [ LlmAlert, ... ] }
```

`LlmAlert` (also returned by `GET /api/status`, below):
```json
{ "purpose": "EXTRACT", "modelId": "groq-llama-70b", "modelLabel": "Llama 3.3 70B (Groq)",
  "status": "EXHAUSTED", "detail": "Daily request limit 1000/1000", "until": "2026-10-18T00:00:00Z",
  "paused": true, "pendingJobs": 23,
  "suggestions": [{ "modelId": "cerebras-llama-70b", "label": "...", "tier": "FREE", "status": "AVAILABLE" }] }
```
One entry per purpose whose assigned model is not `AVAILABLE`. `paused` = LLM work for that
purpose is waiting. `suggestions` = usable models from the assignment's fallbacks, then
other usable registry models (FREE/LOCAL before PAID).

The app header's status line ("Last run 07:00 · 42 new · 9 scored") uses the newest
`pipelineReports` entry. "Today" = since local midnight in `app.pipeline.zone`.
`toReview` = count of the board's default view.

### `POST /api/admin/pipeline/run`
Starts a run asynchronously → 202 `{ "accepted": true }`; 409 `PIPELINE_ALREADY_RUNNING`.
The run makes no LLM calls (ADR-0009).
The UI polls `GET /api/admin/overview` (`pipelineRunning`, newest report).

### `POST /api/admin/collect/{sourceCode}`
Runs one collector + ingest (debug) → 200 `{ collectStatus, fetched, newRaw, newJobs, warnings }`.

### `POST /api/admin/jobs/analyze`
Bulk analysis (extraction, then eligibility) of jobs the admin selected, with the same rules
as `/analyze` (ADR-0009). Body `{ "jobIds": [42, 57], "dryRun": true }`, at most 200 ids.
The admin picks jobs from `GET /api/jobs?analysisStage=NOT_ANALYZED`.

Dry run → `{ "selected": 40, "willAnalyze": 33, "skipped": { "alreadyAnalyzed": 7, "expired": 0 },
"estimatedCalls": 33, "estimatedCostUsd": 0.0 }`. `estimatedCalls` counts the jobs without a
current extraction (one EXTRACT call each). Skipped jobs make no call.

`dryRun: false` → 202 `{ "accepted": true }`. Progress appears in `pipelineProgress` (stage
`ANALYZE`). Errors: 400 `TOO_MANY_JOBS`; 409 `LLM_PAUSED`; 409 `BUDGET_REACHED`, with the same
mid-run rule as bulk scoring.

### `POST /api/admin/jobs/score`
Bulk scoring of jobs the admin selected in the Admin page table (ADR-0009). Body
`{ "jobIds": [42, 57], "dryRun": true }`, at most 200 ids. The admin picks jobs from
`GET /api/jobs?analysisStage=ANALYZED&eligibility=ELIGIBLE&eligibility=UNCERTAIN`.

Dry run → `{ "selected": 40, "willScore": 27, "skipped": { "notAnalyzed": 5, "ineligible": 6,
"alreadyScored": 2 }, "estimatedCalls": 27, "estimatedCostUsd": 0.04 }`. Skipped jobs make no call.

`dryRun: false` → 202 `{ "accepted": true }`. Progress appears in `pipelineProgress`
(stage `SCORE`). Errors: 400 `TOO_MANY_JOBS`; 409 `LLM_PAUSED`; 409 `BUDGET_REACHED` (checked
before the run starts). If the budget runs out mid-run, the remaining jobs stay unscored and the report says so.

### `POST /api/admin/rescore`
Bulk LLM action, admin only. Always run the dry run first; execute only after the owner confirms the count (ADR-0009).
Body `{ "dryRun": true }` → `{ "jobCount": 57, "estimatedCalls": 57, "estimatedCostUsd": 0.09 }`
(cost = average `cost_usd` of SCORE calls in the last 30 days × calls; null if no history); with
`dryRun: false` → 202.

### `POST /api/admin/jobs/{id}/retry`
Body `{ "purpose": "EXTRACT" | "SCORE" }` → resets attempts and re-runs for that job → 202.

### `GET /api/admin/companies`
`[{ id, name, ats, slug, enabled, lastCheckStatus, lastCheckedAt, activeJobs }]`

### `GET /api/status`
Lightweight, polled by the app header on every page every 60 s (every 10 s while a banner
is shown): `{ "lastRun": { "startedAt", "newJobs", "scored", "status" } | null,
"pipelineRunning": false, "llmAlerts": [LlmAlert] }`.

## LLM models (ADR-0008)

### `GET /api/admin/llm`
```json
{ "assignments": [
    { "purpose": "EXTRACT", "modelId": "groq-llama-70b", "fallbacks": ["cerebras-llama-70b", "claude-haiku"],
      "autoFallback": false, "allowPaid": false, "updatedAt": "...", "updatedBy": "user" },
    { "purpose": "SCORE", ... } ],
  "models": [
    { "modelId": "groq-llama-70b", "label": "Llama 3.3 70B (Groq)", "provider": "groq",
      "providerModel": "llama-3.3-70b-versatile", "tier": "FREE",
      "status": "NEAR_LIMIT", "until": null, "detail": "812 / 1000 requests today",
      "limits": { "rpm": 30, "rpd": 1000 },
      "usageToday": { "calls": 812, "inputTokens": 2400000, "outputTokens": 310000, "costUsd": null },
      "keyConfigured": true, "assignedTo": ["EXTRACT", "SCORE"],
      "lastEval": { "date": "2026-10-25", "falseEligible": 0.024, "highRecall": 0.83 } | null } ],
  "history": [{ "purpose", "fromModelId", "toModelId", "reason", "at" }] }
```
`lastEval` is read from the newest matching entry the eval runner records (T-016).

### `PUT /api/admin/llm/assignments/{purpose}`
Body `{ "modelId": "cerebras-llama-70b", "fallbacks": [...], "autoFallback": false, "allowPaid": false }`
(all but `modelId` optional) → 200 updated assignment. Errors: 400 `UNKNOWN_MODEL`,
409 `MODEL_UNUSABLE` (status `ERROR`, e.g. missing key). A manual switch to a PAID model is
allowed (`allowPaid` only limits auto-fallback); the response then includes
`"warning": "PAID model: counts against the monthly budget"`.
Switching writes `llm_assignment_event` (reason `USER`) and un-pauses that purpose; pending
jobs are picked up by the next run, or immediately if the body has `"runNow": true`.

### `POST /api/admin/llm/models/{modelId}/test`
Sends one tiny prompt ("Reply with {\"ok\":true}") → 200 `{ ok, latencyMs, status }`; a
success clears `ERROR`/expired statuses. Logged in `llm_call` with purpose `TEST`.

### `POST /api/admin/eval/export`
Writes `data/eval-candidates.jsonl` (T-016) → `{ "path": "...", "count": 80 }`.
