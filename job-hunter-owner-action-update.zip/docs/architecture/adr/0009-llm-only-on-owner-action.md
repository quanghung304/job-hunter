# ADR-0009: LLM steps run only when the owner asks, one job at a time

Status: Accepted · Date: 2026-10-18 · Amends: ADR-0004 (trigger only; the steps are unchanged)

## Context

The first design ran extraction and scoring for every prefilter-passing job in each
pipeline run. A collection of about 1 000 jobs would then cost about 1 000 extraction calls
and their input tokens, and would use up free daily quotas (ADR-0008) before the owner had
read any of them. Most collected jobs are never opened.

## Decision

1. The pipeline run (collect, ingest, prefilter, expiry, notify) makes **zero** LLM calls.
2. Extraction and eligibility for one job run when the owner presses "Analyze" on that
   job (`POST /api/jobs/{id}/analyze`). At most one EXTRACT call. Eligibility is Java code and costs nothing.
3. Scoring for one job runs when the owner presses "Score" (`POST /api/jobs/{id}/score`),
   and only if eligibility is ELIGIBLE or UNCERTAIN. One SCORE call.
4. Bulk LLM actions are explicit admin actions only. The admin selects jobs in a table and
   analyzes or scores them; "Re-score active jobs" and "Retry failed" are the other two. Each action shows the job count and
   the estimated calls before it runs: "Re-score active jobs" and "Retry failed". Nothing else
   batches LLM work.
5. Results are cached per job and prompt version. Pressing a button again for a job that is
   already done makes no call.
6. The budget guard, quota statuses and banner (ADR-0008) apply to every manual call. A paused
   purpose disables its buttons and links to the model switch dialog.

## Alternatives considered

- Keep automatic extraction, but only for the newest N jobs per run. This still spends quota
  on jobs the owner never opens, and N is a guess.
- Keep automatic scoring, but only for jobs that pass eligibility. Eligibility needs
  extraction first, so the same cost problem remains.

## Consequences

- New jobs wait as `NOT_ANALYZED` on the board. The default view lists scored jobs first and
  unanalyzed jobs after them, so the owner chooses which jobs to spend calls on.
- Telegram: the digest reports the number of new unanalyzed jobs and the scored jobs at or
  above the digest threshold. Instant alerts are removed (owner decision, 2026-10-18).
- Scoring covers only the jobs the owner analyzed. The eval (T-016) is not affected.
- No schema change. `analysisStage` is derived from existing `job_extraction` and
  `job_assessment` rows.
