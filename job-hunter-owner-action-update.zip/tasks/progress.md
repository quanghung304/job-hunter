# Progress log

Newest entry on top. Each entry, max ~10 lines:

```
## YYYY-MM-DD — T-XXX <title> — DONE | PARTIAL | BLOCKED
- What was built (key classes/files)
- Deviations from spec and why (and which doc was updated)
- Open issues / follow-ups (create tasks if needed)
- Next suggested task
```

## 2026-10-18 — Bulk analysis added; button labels in English (docs) — DONE
- Admin: bulk analysis of selected jobs (`POST /api/admin/jobs/analyze`, dry run first, max
  200), alongside bulk scoring. One table with an Analyze / Score mode and one dialog.
- Button labels are English: "Analyze" and "Score" (the Vietnamese labels are removed).
- Updated: api-spec, ADR-0009, overview, PRD, runbook, frontend.md, T-011, T-014, T-020, T-021.

## 2026-10-18 — Owner decisions: no instant alerts, admin bulk scoring, analysis buttons (docs) — DONE
- Telegram: instant alerts removed (`notify.alertMinScore` dropped); digest only.
- Admin: select jobs in a table and score them in bulk (`POST /api/admin/jobs/score`, dry run
  first, max 200). No bulk analyze in Phase 1.
- Board, job detail and mobile: "Analyze" and "Score" buttons (`AnalysisActions`),
  filter by analysis stage. The two labels are Vietnamese by owner request.
- Updated: PRD (G5, F2.5, F2.10), overview, config-spec, profile.example, runbook, data-model
  (notification kinds), ADR-0009, api-spec, frontend.md. Tasks: T-012, T-014, T-015, T-021.

## 2026-10-18 — LLM only on owner action, per job (docs) — DONE
- ADR-0009: pipeline makes zero LLM calls. Extraction + eligibility run when the owner
  presses "Analyze" on a job; scoring when they press "Score". Bulk LLM actions
  stay admin-only with a dry-run count.
- Updated: overview (pipeline run, LLM on owner action), scoring-spec §1/§6/§8, PRD F1.6,
  F1.8, F2.10, api-spec (analyze/score endpoints, `analysisStage`, default view), runbook,
  AGENTS.md, ADR-0004 (trigger amended). Tasks: T-011, T-012, T-013, T-014, T-020 adjusted.
- Open: frontend.md board/detail still needs the two buttons; Telegram instant alerts
  may be dropped (ADR-0009 consequences).

## 2026-10-17 — Free-tier LLMs, quota alerts, model switching (docs) — DONE
- ADR-0008: model registry `config/llm.yaml` (Groq free by default; Cerebras, GitHub
  Models, OpenRouter, Ollama, Claude Haiku as options), OpenAI-compatible client,
  per-purpose assignments switchable at runtime, quota tracking, Telegram + banner alerts.
- Updated: PRD (F2.8, F2.9, G6, G7), config-spec §2/§3/§5, data-model (`llm_call` columns,
  `llm_assignment`, `llm_assignment_event`, `llm_model_state`, `eval_run`, `notification`),
  overview, api-spec, frontend.md, scoring-spec §6/§8, testing, runbook, eval README,
  AGENTS.md, ADR-0004, `.env.example`. Tasks: T-010 rewritten, T-013/T-014/T-016/T-021
  adjusted, new T-022 (backend) and T-023 (frontend).
- Banner, switch dialog and LLM models card are specified in frontend.md but not drawn in
  the mockups yet.

## 2026-10-17 — UI design approved — DONE
- Mockups approved in the Claude Design canvas "Job Hunter UI mockups" (5 artboards).
- `frontend.md` now holds design tokens, typography, component specs, layouts and
  behavior ("inbox triage", split view ≥ 1024px). Added `o` and `Esc` shortcuts.
- `api-spec.md`: overview gained `kpis`, `schedule`, `pipelineProgress`; re-score dry run
  gained `estimatedCostUsd`. T-014, T-019, T-020, T-021 updated accordingly.

## 2026-10-16 — Switch UI to React SPA — DONE
- ADR-0007 supersedes ADR-0006 (UI part): monorepo `backend/` + `frontend/`, REST API under
  `/api`, OpenAPI contract at `docs/architecture/openapi.json`, React + Vite + TanStack Query.
- Added `api-spec.md`, `frontend.md`; updated AGENTS, overview, conventions, testing, runbook.
- Old T-014 (Thymeleaf UI) replaced by T-014 (REST API), T-019 (FE bootstrap),
  T-020 (board + detail), T-021 (admin).
- Next: T-001.

## 2026-10-16 — Documentation set — DONE
- PRD, roadmap, architecture, data model, config spec, ADR-0001..0006, source specs,
  scoring spec, prompts v1 (draft), eval plan, task specs T-001..T-018.
- Source field shapes are **unverified**; each collector task starts by capturing a real response.
- Next: T-001.
